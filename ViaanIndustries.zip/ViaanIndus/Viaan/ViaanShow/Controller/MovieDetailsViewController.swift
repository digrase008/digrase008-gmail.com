//
//  MovieDetailsViewController.swift
//  ViaanShow
//
//  Created by Heckyl on 25/03/20.
//  Copyright © 2020 AppCoda. All rights reserved.
//

import UIKit

class MovieDetailsViewController: UIViewController {

    @IBOutlet weak var lbl_MovieName: UILabel!
    @IBOutlet weak var btn_Back: UIButton!
    @IBOutlet weak var lbl_Adult: UILabel!
    @IBOutlet weak var lbl_ReleaseDate: UILabel!
    @IBOutlet weak var lbl_Popularity: UILabel!
    @IBOutlet weak var lbl_AvgVote: UILabel!
    @IBOutlet weak var lbl_VoteCount: UILabel!
    @IBOutlet weak var lbl_Summary: UILabel!
    @IBOutlet weak var v_CertiType: UIView!
    @IBOutlet weak var v_releaseDate: UIView!
    @IBOutlet weak var v_avgVote: UIView!
    @IBOutlet weak var v_VoteCount: UIView!
    @IBOutlet weak var v_Popularity: UIView!
    
    
    var movieDetails: AnyObject!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setData()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        DispatchQueue.main.async {
            self.setTheme()
        }
    }
    
    func setTheme() {
        v_releaseDate.layer.cornerRadius = 10
        v_CertiType.layer.cornerRadius = 10
        v_Popularity.layer.cornerRadius = 10
        v_avgVote.layer.cornerRadius = 10
        v_VoteCount.layer.cornerRadius = 10
    }
    
    func setData() {
        lbl_MovieName.text = movieDetails["title"] as? String ?? ""
        lbl_Adult.text = movieDetails["adult"] as? Bool ?? Bool() ? "Adult" : "Unrestricted"
        lbl_ReleaseDate.text = "Release Date: \(movieDetails["release_date"] as? String ?? "NA")"
        lbl_Popularity.text = "Popularity: \(movieDetails["popularity"] as? Double ?? Double())"
        lbl_AvgVote.text = "Avg Vote: \(movieDetails["vote_average"] as? Double ?? Double())"
        lbl_VoteCount.text = "Vote Count: \(movieDetails["vote_count"] as? Int ?? Int())"
        lbl_Summary.text = movieDetails["overview"] as? String ?? ""
    }
    
    @IBAction func backAction(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    
}
