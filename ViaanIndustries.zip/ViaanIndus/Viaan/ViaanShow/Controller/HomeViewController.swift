//
//  HomeViewController.swift
//  ViaanShow
//
//  Created by Akshay Digrase on 24/03/2020.
//  Copyright © 2020 HellBoy. All rights reserved.
//


import UIKit
import Firebase
import FirebaseAuth

class HomeViewController: UIViewController, squadServiceDelegate, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet weak var tv_UpcomingMovies: UITableView!
    var movieReq : SquadService!
    var upcomingMovies: [AnyObject] = []
    var currentPage: Int!
    var totalPages: Int!
    override func viewDidLoad() {
        super.viewDidLoad()
        movieReq = SquadService()
        movieReq.delegate = self
//        tv_UpcomingMovies.separatorColor = UIColor(hexString: "#AD3961")
        movieReq.getTeamDetails()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    @IBAction func logOutAction(sender: AnyObject) {
        if FIRAuth.auth()?.currentUser != nil {
            do {
                try FIRAuth.auth()?.signOut()
                let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "SignUp")
                present(vc, animated: true, completion: nil)
                
            } catch let error as NSError {
                print(error.localizedDescription)
            }
        }
    }
    
    func responseData(_ data: Any) {
        upcomingMovies.append(contentsOf: ((data as? [String: AnyObject])?["results"] as? [AnyObject] ?? []))
        currentPage = (data as? [String: AnyObject])?["page"] as? Int ?? 0
        totalPages = (data as? [String: AnyObject])?["total_pages"] as? Int ?? 0
        if upcomingMovies.count > 0 {
            DispatchQueue.main.async {
                self.tv_UpcomingMovies.reloadData()
            }
        }
        print(upcomingMovies)
    }
    
    func errorResponse(_ err: Error) {
        print(err)
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
       return upcomingMovies.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tv_UpcomingMovies.dequeueReusableCell(withIdentifier: "upcomingMovies", for: indexPath) as? UpcomingMoviesTVC else {
            fatalError("The dequeued cell is not an instance of SquadTVC")
        }
        if indexPath.row == upcomingMovies.count - 1 && currentPage < totalPages{
            movieReq.getTeamDetails(page: currentPage+1)
        }
        cell.lbl_MovieName.text = upcomingMovies[indexPath.row]["title"] as? String ?? ""
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        performSegue(withIdentifier: "movieListToDetails", sender: upcomingMovies[indexPath.row])
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "movieListToDetails" {
            let vc = segue.destination as! MovieDetailsViewController
            vc.movieDetails = sender as AnyObject
        }
    }
    
}
