//
//  SignUpViewController.swift
//  ViaanShow
//
//  Created by Akshay Digrase on 24/03/2020.
//  Copyright © 2020 HellBoy. All rights reserved.
//

import UIKit
import Firebase
import FirebaseAuth

class SignUpViewController: UIViewController {

    //Outlets
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet var mobileNumberTextField: UITextField!
    @IBOutlet var fullnameTextField: UITextField!
    
    
    //Sign Up Action for email
    @IBAction func createAccountAction(_ sender: AnyObject) {
        if emailTextField.text == "" {
            
            alertDialog(msg: "Please enter your email and password")
            
        } else if mobileNumberTextField.text == "" {
            
            alertDialog(msg: "Please enter your mobile number")
            
        } else if fullnameTextField.text == "" {
            
            alertDialog(msg: "Please enter your full name")
            
        } else
        {
            FIRAuth.auth()?.createUser(withEmail: emailTextField.text!, password: passwordTextField.text!) { (user, error) in
                
                if error == nil {
                    print("You have successfully signed up")
                    //Goes to the Setup page which lets the user take a photo for their profile picture and also chose a username
                    
                    let vc = self.storyboard?.instantiateViewController(withIdentifier: "Home")
                    self.present(vc!, animated: true, completion: nil)
                    
                } else {
                    let alertController = UIAlertController(title: "Error", message: error?.localizedDescription, preferredStyle: .alert)
                    
                    let defaultAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
                    alertController.addAction(defaultAction)
                    
                    self.present(alertController, animated: true, completion: nil)
                }
            }
        }
    }
    
    func alertDialog(msg : String) {
        let alertController = UIAlertController(title: "Error", message: msg, preferredStyle: .alert)
        
        let defaultAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
        alertController.addAction(defaultAction)
        
        present(alertController, animated: true, completion: nil)
    }
    
    
}

