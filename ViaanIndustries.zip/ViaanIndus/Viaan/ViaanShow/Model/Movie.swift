//
//  Movie.swift
//  ViaanShow
//
//  Created by Akshay Digrase on 26/03/20.
//  Copyright © 2020 AppCoda. All rights reserved.
//

import Foundation

struct Movie {
    var movieName: String = ""
    var Certificate: String = ""
    var releaseDate: String = ""
    var popularity: Double = 0.0
    var averageVote: Double = 0.0
    var voteCount: Int = 0
    var Summary: String = ""
}
